/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda.DAO.Telefone;

import agenda.DAO.ErroBancoException;
import agenda.Modelo.Contato;
import agenda.Modelo.Telefone;
import java.util.List;

/**
 *
 * @author wellikson
 */
public interface TelefoneDaoInterface {
    public void criarTelefone(Telefone t,Contato c) throws ErroBancoException;
    public Telefone pegaTelefone(int codigo) throws ErroBancoException;
    public List<Telefone> pegaTelefones() throws ErroBancoException;
    public List<Telefone> pegaTelefones(Contato c) throws ErroBancoException;
    public void deletarTelefone(int codigo) throws ErroBancoException;
    public void sair() throws ErroBancoException;
}
