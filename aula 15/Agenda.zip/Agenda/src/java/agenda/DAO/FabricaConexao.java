/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author wellikson
 */
public class FabricaConexao {
    public Connection pegaConexao() throws ErroBancoException {
        Connection con = null;
        try {

            InitialContext ic = new InitialContext();
            DataSource ds = (DataSource) ic.lookup("ResponseAgendaPool");
            con = ds.getConnection();
            return con;
        } catch (NamingException |SQLException ex) {
            throw new ErroBancoException(ex);
        }
    }
}
