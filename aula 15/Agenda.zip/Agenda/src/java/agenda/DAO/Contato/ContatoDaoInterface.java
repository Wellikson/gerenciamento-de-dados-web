/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda.DAO.Contato;

import agenda.DAO.ErroBancoException;
import agenda.Modelo.Contato;
import java.util.List;

/**
 *
 * @author wellikson
 */
public interface ContatoDaoInterface {
    public void criarContato(Contato c)throws ErroBancoException;
    public Contato pegaContato(int codigo) throws ErroBancoException;
    public List<Contato> pegaContatos() throws ErroBancoException;
    public void deletarContato(int codigo) throws ErroBancoException;
    public void sair() throws ErroBancoException;

}
