/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda.DAO.Contato;

import agenda.DAO.ErroBancoException;
import agenda.DAO.FabricaConexao;
import agenda.DAO.Telefone.TelefoneDaoClasse;
import agenda.Modelo.Contato;
import agenda.Modelo.Telefone;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wellikson
 */
public class ContatoDaoClasse implements ContatoDaoInterface {

    Connection con;

    public ContatoDaoClasse() throws ErroBancoException {
        con = new FabricaConexao().pegaConexao();
    }

    @Override
    public void criarContato(Contato c) throws ErroBancoException {
        try {
            PreparedStatement ps = con.prepareStatement("insert into contato values(null,?)",Statement.RETURN_GENERATED_KEYS);
            ps.setString(1,c.getNome());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
                c.setCodigo(rs.getInt(1));
            }
            rs.close();
            ps.close();
            TelefoneDaoClasse dao = new TelefoneDaoClasse();
            List<Telefone> fones = c.getTelefones();
            for(Telefone f:fones){
                dao.criarTelefone(f,c);
            }
            dao.sair();
        } catch (SQLException ex) {
            throw new ErroBancoException(ex);
        }

    }

    @Override
    public Contato pegaContato(int codigo) throws ErroBancoException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Contato> pegaContatos() throws ErroBancoException {
         List<Contato>agenda = new ArrayList<>();
        try {
            PreparedStatement ps = con.prepareStatement("Select codigo,nome from contato");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Contato c = new Contato();
                c.setCodigo(rs.getInt(1));
                c.setNome(rs.getString(2));
                agenda.add(c);
                TelefoneDaoClasse dao = new TelefoneDaoClasse();
                c.setTelefones(dao.pegaTelefones(c));
                dao.sair();
           }
            rs.close();
            ps.close();
            return agenda;
        } catch (SQLException ex) {
            throw new ErroBancoException(ex);
        }
        
    }

    @Override
    public void deletarContato(int codigo) throws ErroBancoException {
        try {
            PreparedStatement ps = con.prepareStatement("delete from contato where codigo=?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            throw new ErroBancoException(ex);
        }
    }
    
    @Override
    public void sair() throws ErroBancoException {
        try {
            con.close();
        } catch (SQLException ex) {
            throw new ErroBancoException(ex);
        }
    }

}
