/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function criarAjaxGet(url, dados, funcao) {
    let ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("GET", url + "?" + dados, true);
    ajax.send();
}
function criarAjaxPost(url, dados, funcao) {
    let ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("POST", url, true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(dados);
}
document.getElementById("botao").onclick = () => {
    criarAjaxGet("mostrar", "", geraTabela);
}
function geraTabela() {
    if (this.readyState === 4 && this.status === 200) {

        let text = "";
        let contatos = this.responseXML.documentElement.getElementsByTagName("contato");
        let tabela = document.getElementById("corpo");
        for (let contato of contatos) {
            let cod = contato.getElementsByTagName("codigo")[0].firstChild.nodeValue;
            text += "<tr>";
            text += "<td>" + contato.getElementsByTagName("codigo")[0].firstChild.nodeValue + "</td>";
            text += "<td>" + contato.getElementsByTagName("nome")[0].firstChild.nodeValue + "</td>";
            text += "<td>" + listaDeTelefones(contato.getElementsByTagName("telefone")) + "</td>";
            text += '<td><button type="button" onclick="{apagar(\'contato\',' + cod + ')}" class="btn btn-warning">Apagar</button></td>';
            text += "</tr>";

        }
        tabela.innerHTML = text;

    }
}
function listaDeTelefones(telefones) {
    let text = "<ul>";
    let tam = telefones.length;
    for (let fone of telefones) {
        let cod = +fone.getElementsByTagName("codigo")[0].firstChild.nodeValue;
        text += "<li> " + fone.getElementsByTagName("tipo")[0].firstChild.nodeValue + " (" + fone.getElementsByTagName("ddd")[0].firstChild.nodeValue + ")";
        text += fone.getElementsByTagName("numero")[0].firstChild.nodeValue + "  ";
        if (tam > 1) {
            text += '<button type="button" onclick="{apagar(\'telefone\',' + cod + ')}" class="btn btn-info">x</li>';
        }
    }
    return text += "</ul>";
}
document.getElementById("btAddTelefone").onclick = () => {
    let text = '<section>\
                    <input type="text" class="ddd" placeholder="DDD">\
                    <input type="text" class="numero" placeholder="Número">\
                    <input type="text" class="tipo" placeholder="Tipo">\
                    <button type="button" class="btRemover" onclick="remover(this)">x</button>\
                </section>';
    document.getElementById("telefones").innerHTML += text;
}
function remover(botao) {
    let pai = botao.parentNode;
    pai.parentNode.removeChild(pai);
}
function apagar(acao, codigo) {
    let r = confirm("Deseja Apagar o " + acao + " ?");
    if (r === true) {
        criarAjaxPost("apagar", acao + "=" + codigo,
                function () {
                    if (this.readyState === 4 && this.status === 200) {
                        alert(this.responseText);
                        criarAjaxGet("mostrar", "", geraTabela);
                    }
                }
        );
    }

}

document.getElementById("btCadastrar").onclick = () => {
    let text = "<contato><nome>" + document.getElementById("nome").value + "</nome>";
    text += pegaTelefones();
    text += "</contato>";
    criarAjaxPost("inserir", "xml=" + text,
            function () {
                if (this.readyState === 4 && this.status === 200) {
                    alert(this.responseText);
                }
            }
    );
}
function pegaTelefones() {
    let ddds = document.querySelectorAll(".ddd");
    let numeros = document.querySelectorAll(".numero");
    let tipos = document.querySelectorAll(".tipo");
    let tam = ddds.length;
    let text = "<telefones>";
    for (let i = 0; i < tam; i++) {
        text += montaTelefone(ddds[i], numeros[i], tipos[i]);
    }
    return text += "</telefones>";
}
function montaTelefone(ddd, numero, tipo) {
    let text = "<telefone>";
    text += "<numero>" + numero.value + "</numero>";
    text += "<ddd>" + ddd.value + "</ddd>";
    text += "<tipo>" + tipo.value + "</tipo>";
    return text += "</telefone>";
}