var text = 
"<bookstore id='oi' classe='raiz'>"+
"   <book>"+
        "<title>Everyday Italian</title>"+
        "<author>Giada de Laurentiis</author>"+
        "<author>José Silva</author>"+
        "<author>Maria Beatriz</author>"+
        "<year>2005</year>"+
    "</book>"+
"   <book>"+
        "<title>Livro 2</title>"+
        "<author>Pedro Silva</author>"+
        "<author>Carlos Beatriz</author>"+
        "<year>2008</year>"+
    "</book>"+
"</bookstore>";