/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author wellikson
 */
public class ErroDaoException extends Exception{

    public ErroDaoException() {
        super("Erro na base de dados");
    }

    public ErroDaoException(String string) {
        super(string);
    }

    public ErroDaoException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public ErroDaoException(Throwable thrwbl) {
        super(thrwbl);
    }

    public ErroDaoException(String string, Throwable thrwbl, boolean bln, boolean bln1) {
        super(string, thrwbl, bln, bln1);
    }
    
}
