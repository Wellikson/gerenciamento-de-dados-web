/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PessoaDaoClasseBanco implements PessoaDaoInterface {

    Connection con;

    public PessoaDaoClasseBanco() throws ErroDaoException {
        FabricaConexao fc = new FabricaConexao();
        con = fc.pegaConexao();
    }

    @Override
    public void criarPessoa(Pessoa p) throws ErroDaoException{
        try {
            PreparedStatement ps = con.prepareStatement("insert into Pessoa values(null,?,?)");
            ps.setString(1, p.getNome());
            ps.setInt(2, p.getIdade());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            throw new ErroDaoException(ex);
        }
    }

    @Override
    public List<Pessoa> pegaPessoas() throws ErroDaoException {
        try {
            ArrayList<Pessoa> grupo = new ArrayList<>();
            PreparedStatement ps = con.prepareStatement("select * from Pessoa");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setCodigo(rs.getInt(1));
                p.setNome(rs.getString(2));
                p.setIdade(rs.getInt(3));
                grupo.add(p);
            }
            
            return grupo;
        } catch (SQLException ex) {
            throw new ErroDaoException(ex);
        }
    }

    public void sair() throws ErroDaoException {
        try {
            con.close();
        } catch (SQLException ex) {
            throw new ErroDaoException("Erro ao sair", ex);
        }
    }

    @Override
    public Pessoa pegaPessoa(int codigo) throws ErroDaoException {
        try {
            PreparedStatement ps = con.prepareStatement("select * from Pessoa where codigo=?");
            ps.setInt(1, codigo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Pessoa p = new Pessoa();
                p.setCodigo(rs.getInt(1));
                p.setNome(rs.getString(2));
                p.setIdade(rs.getInt(3));
                return p;
            }
            return null;
        } catch (SQLException ex) {
           throw new ErroDaoException(ex);
        }
    }

    @Override
    public void deletarPessoa(int codigo) throws ErroDaoException  {
        try {
            PreparedStatement ps = con.prepareStatement("delete from Pessoa where codigo=?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            throw new ErroDaoException(ex);
        }
    }

    @Override
    public void deletarPessoa(Pessoa p) throws ErroDaoException  {
        deletarPessoa(p.getCodigo());
    }

    @Override
    public void editarPessoa(Pessoa p) throws ErroDaoException  {
        try {
            PreparedStatement ps = con.prepareStatement("update Pessoa set nome = ?, idade = ?  where codigo=?");
            ps.setString(1, p.getNome());
            ps.setInt(2, p.getIdade());
            ps.setInt(3, p.getCodigo());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            throw new ErroDaoException(ex);
        }
    }

    public static void main(String[] args) throws SQLException {
        try {
            PessoaDaoClasseBanco dao = new PessoaDaoClasseBanco();
            System.out.println("conectado com sucesso");
            Pessoa p1 = new Pessoa();
//            p.setNome("Izadora");
//            p.setIdade(16);
//            dao.criarPessoa(p);

            List<Pessoa> pessoas = dao.pegaPessoas();
            for (Pessoa p : pessoas) {
                System.out.println(p.toString());
            }

            System.out.println("\n\nPessoa de codigo :7");
            System.out.println(dao.pegaPessoa(21));

//            dao.deletarPessoa(6);
//            p1.setCodigo(5);
//            dao.deletarPessoa(p1);
            p1.setCodigo(dao.pegaPessoa(8).getCodigo());
            p1.setNome(dao.pegaPessoa(8).getNome());
            p1.setIdade(18);
            dao.editarPessoa(p1);
            dao.sair();

            System.out.println("fechado com sucesso");
        } catch (ErroDaoException ex) {
            System.out.println(ex.toString());
        }

    }

}
