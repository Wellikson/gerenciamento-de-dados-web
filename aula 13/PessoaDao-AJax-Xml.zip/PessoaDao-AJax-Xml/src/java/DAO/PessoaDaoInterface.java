/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Pessoa;
import java.util.List;

/**
 *
 * @author wellikson
 */
public interface PessoaDaoInterface {

    public void criarPessoa(Pessoa p) throws ErroDaoException;
    public List<Pessoa> pegaPessoas()throws ErroDaoException;
    public Pessoa pegaPessoa(int codigo)throws ErroDaoException;
    public void deletarPessoa(int codigo)throws ErroDaoException;
    public void deletarPessoa(Pessoa p)throws ErroDaoException;
    public void editarPessoa(Pessoa p)throws ErroDaoException;
    public void sair() throws ErroDaoException;
}
