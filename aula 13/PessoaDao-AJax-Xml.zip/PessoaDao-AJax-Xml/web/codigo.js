
function criaAjax(url, funcao){
    let ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("GET", url, true);
    ajax.send();
}

function ajaxPost(url,dados, funcao){
    let ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("POST", url, true);
    ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    ajax.send(dados);
}

document.getElementById('botao').onclick = (evento)=>{
    evento.preventDefault();
    let nome = document.getElementById("nome").value;
    let idade = document.getElementById("idade").value;
    let codigo = document.getElementById("codigo").value;
    let dados = `nome=${nome}&idade=${idade}&codigo=${codigo}`;
    ajaxPost("inserirXml",dados,
        function(){
            if(this.readyState === 4 && this.status === 200){
                alert(this.responseText);
                 criaAjax("mostrarxml", mostrar);
            }
        });
};

function mostrar(){
    document.getElementById("codigo").value = "";
    document.getElementById("nome").value = "";
    document.getElementById("idade").value = "";
    document.getElementById("botao").value = "Inserir";
    if (this.readyState === 4 && this.status === 200)
    {
        let raiz = this.responseXML.documentElement;
        let pessoas = raiz.getElementsByTagName("pessoa");
        let texto = "<table class=\"table table-dark table-hover\">";
        texto += "<tr><th>Código</th><th>Nome</th><th>Idade</th><th>Editar</th><th>Apagar</th></tr>";
        for (let pessoa of pessoas)
        {
            texto += pegarPessoa(pessoa);
        }
        texto += "</table>";
        document.getElementById("retorno").innerHTML = texto;
    }
}
function pegarPessoa(pessoa){
    let texto = "<tr>";
    let filhos = pessoa.childNodes;
    let codigo = pessoa.getElementsByTagName("codigo")[0].firstChild.nodeValue;
    for (let filho of filhos)
    {
        if (filho.nodeType === 1)
            texto += "<td>" + filho.firstChild.nodeValue + "</td>";
    }
    //Editar
    texto += '<td><button type="button" onclick="{funEditar(' + codigo + ')}" class="btn btn-warning">Editar</button></td>';
//    Apagar
    texto += '<td><button type="button" onclick="{funApagar(' + codigo + ')}" class="btn btn-danger">Apagar</button></td>';
    return texto + "</tr>";
}

function editar(){

    if (this.readyState === 4 && this.status === 200)
    {
        let raiz = this.responseXML.documentElement;
        let codigo = raiz.getElementsByTagName("codigo")[0].firstChild.nodeValue;
        let nome = raiz.getElementsByTagName("nome")[0].firstChild.nodeValue;
        let idade = raiz.getElementsByTagName("idade")[0].firstChild.nodeValue;
        document.getElementById("codigo").value = codigo;
        document.getElementById("nome").value = nome;
        document.getElementById("idade").value = idade;
        document.getElementById("botao").value = "Atualizar";
    }
}

function funEditar(codigo) {
    criaAjax("editarxml?codigo=" + codigo, editar);
}
function funApagar(codigo) {
    criaAjax("apagarxml?codigo=" + codigo,function(){
            if(this.readyState === 4 && this.status === 200){
                alert(this.responseText);
                 criaAjax("mostrarxml", mostrar);
            }
        });
}
onload = () => {criaAjax("mostrarxml", mostrar);};

